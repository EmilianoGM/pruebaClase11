﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Medina.Emiliano._2A
{
    public class Shopping
    {
        private int _capacidad;
        private List<Comercio> _comercios;

        public double PrecioDeExportadores
        {
            get
            {
                return this.ObtenerPrecio(EComercio.Exportador);
            }
        }

        public double PrecioDeImportadores
        {
            get
            {
                return this.ObtenerPrecio(EComercio.Importador);
            }
        }

        public double PrecioTotal
        {
            get
            {
                return this.ObtenerPrecio(EComercio.Ambos);
            }
        }

        private Shopping()
        {
            this._comercios = new List<Comercio>();
        }
        private Shopping(int capacidad) : this()
        {
            this._capacidad = capacidad;
        }

        public static string Mostrar(Shopping s)
        {
            string retorno = "***************************\nListado de comercios\n***************************\n";
            foreach(Comercio comercio in s._comercios)
            {
                if(comercio is Exportador)
                {
                    retorno = retorno + ((Exportador)comercio).Mostrar() + "\n";
                } else if (comercio is Importador)
                {
                    retorno = retorno + ((Importador)comercio).Mostrar() + "\n";
                } else
                {
                    retorno = retorno + comercio + "\n";
                }
            }
            return retorno;
        }

        public static implicit operator Shopping(int capacidad)
        {
            return new Shopping(capacidad);
        }

        public static bool operator ==(Shopping s, Comercio c)
        {
            bool retorno = false;
            if (Object.Equals(s, null) && Object.Equals(c, null))
            {
                retorno = true;
            }
            else if (!(Object.Equals(s, null) && Object.Equals(c, null)))
            {
                foreach (Comercio comercio in s._comercios)
                {
                    if (comercio is Exportador && c is Exportador)
                    {
                        retorno = (Exportador)comercio == (Exportador)c;
                        if(retorno)
                        {
                            break;
                        }
                    }
                    else if (comercio is Importador && c is Importador)
                    {
                        retorno = (Importador)comercio == (Importador)c;
                        if(retorno)
                        {
                            break;
                        }
                    } else
                    {
                        retorno = comercio == c;
                        if(retorno)
                        {
                            break;
                        }
                    }
                }
            }
            return retorno;
        }

        public static bool operator !=(Shopping s, Comercio c)
        {
            return !(s == c);
        }

        public static Shopping operator +(Shopping s, Comercio c)
        {
            if(!(Object.Equals(s, null) && Object.Equals(c, null)))
            {
                if(s != c && s._comercios.Count < s._capacidad)
                {
                    s._comercios.Add(c);
                } else if(s == c)
                {
                    Console.WriteLine("El comercio ya esta en el shopping!!");
                } else if(s._comercios.Count < s._capacidad)
                {
                    Console.WriteLine("No hay mas lugar en el Shopping!!");
                }
            }
            return s;
        }

        private double ObtenerPrecio(EComercio tipoComercio)
        {
            double retorno = 0;
            if (tipoComercio.Equals(EComercio.Importador))
            {
                foreach (Comercio comercio in this._comercios)
                {
                    if (comercio is Importador)
                    {
                        retorno += (Importador)comercio;
                    }
                }
            } else if (tipoComercio.Equals(EComercio.Exportador))
            {
                foreach (Comercio comercio in this._comercios)
                {
                    if (comercio is Exportador)
                    {
                        retorno += (Exportador)comercio;
                    }
                }
            } else if (tipoComercio.Equals(EComercio.Ambos))
            {
                foreach (Comercio comercio in this._comercios)
                {
                    if (comercio is Exportador)
                    {
                        retorno += (Exportador)comercio;
                    } else if (comercio is Importador)
                    {
                        retorno += (Importador)comercio;
                    }
                }
            }
            return retorno;
        }
    }
}
