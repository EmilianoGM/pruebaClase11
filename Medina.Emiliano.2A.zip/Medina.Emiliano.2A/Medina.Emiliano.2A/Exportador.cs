﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Medina.Emiliano._2A
{
    public class Exportador : Comercio
    {
        public ETipoProducto tipo;

        public Exportador(string nombreComercio, float precioAlquiler, string nombre, string apellido, ETipoProducto tipo) : base(precioAlquiler, nombreComercio, nombre, apellido)
        {
            this.tipo = tipo;
        }

        public static implicit operator double(Exportador a)
        {
            return a._precioAlquiler;
        }

        public string Mostrar()
        {
            return (string)((Comercio)this) + "\nTIPO: " + this.tipo.ToString();
        }

        public static bool operator ==(Exportador a, Exportador b)
        {
            bool retorno = false;
            if (Object.Equals(a, null) && Object.Equals(b, null))
            {
                retorno = true;
            }
            else if (!(Object.Equals(a, null) && Object.Equals(b, null)))
            {
                if ((Comercio)a == (Comercio)b && a.tipo.Equals(b.tipo))
                {
                    retorno = true;
                }
            }
            return retorno;
        }

        public static bool operator !=(Exportador a, Exportador b)
        {
            return !(a == b);
        }
    }
}
