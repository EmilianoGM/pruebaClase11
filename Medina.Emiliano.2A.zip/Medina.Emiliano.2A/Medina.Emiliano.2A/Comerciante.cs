﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Medina.Emiliano._2A
{
    public class Comerciante
    {
        private string apellido;
        private string nombre;

        public Comerciante(string nombre, string apellido)
        {
            this.apellido = apellido;
            this.nombre = nombre;
        }

        public static implicit operator string(Comerciante a)
        {
            return a.nombre + " - " + a.apellido;
        }

        public static bool operator ==(Comerciante a, Comerciante b)
        {
            bool retorno = false;
            if (Object.Equals(a, null) && Object.Equals(b, null))
            {
                retorno = true;
            } else if (!(Object.Equals(a, null) && Object.Equals(b, null)))
            {
                if(a.nombre.Equals(b.nombre) && a.apellido.Equals(b.apellido))
                {
                    retorno = true;
                }
            }
            return retorno;
        }

        public static bool operator !=(Comerciante a, Comerciante b)
        {
            return !(a == b);
        }

    }
}
