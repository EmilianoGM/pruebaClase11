﻿public enum EPaises
{
    China,
    Taiwan,
    UnionEuropea
}