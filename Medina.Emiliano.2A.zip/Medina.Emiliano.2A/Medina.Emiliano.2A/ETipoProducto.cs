﻿public enum ETipoProducto
{
    Tecnologico,
    Rural,
    Varios
}