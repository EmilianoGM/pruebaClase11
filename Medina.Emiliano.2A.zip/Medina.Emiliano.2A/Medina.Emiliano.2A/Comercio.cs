﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Medina.Emiliano._2A
{
    public class Comercio
    {
        protected int _cantidadDeEmpleados = 0;
        protected Comerciante _comerciante;
        protected static Random _generadorDeEmpleados;
        protected string _nombre;
        protected float _precioAlquiler;

        static Comercio()
        {
            _generadorDeEmpleados = new Random();
        }

        public int CantidadDeEmpleados
        {
            get
            {
                if(this._cantidadDeEmpleados == 0)
                {
                    this._cantidadDeEmpleados = _generadorDeEmpleados.Next(1, 100);
                }
                return this._cantidadDeEmpleados;
            }
        }

        public Comercio(float precioAlquiler, string nombreComercio, string nombre, string apellido) : this(nombreComercio, new Comerciante(nombre, apellido), precioAlquiler)
        {
        }

        public Comercio(string nombre, Comerciante comerciante, float precioAlquiler)
        {
            this._nombre = nombre;
            this._precioAlquiler = precioAlquiler;
            this._comerciante = comerciante;
            this._cantidadDeEmpleados = this.CantidadDeEmpleados;
        }

        public static explicit operator string(Comercio c)
        {
            return Comercio.Mostrar(c);
        }

        private static string Mostrar(Comercio c)
        {
            string retorno = "NOMBRE: " + c._nombre + "\nCANTIDAD DE EMPLEADOS: " + c._cantidadDeEmpleados.ToString() + "\nCOMERCIANTE: ";
            retorno += c._comerciante + "\nPRECIO ALQUILER: " + c._precioAlquiler.ToString();
            return retorno;
        }

        public static bool operator ==(Comercio a, Comercio b)
        {
            bool retorno = false;
            if (Object.Equals(a, null) && Object.Equals(b, null))
            {
                retorno = true;
            }
            else if (!(Object.Equals(a, null) && Object.Equals(b, null)))
            {
                if (a._nombre.Equals(b._nombre) && a._comerciante == b._comerciante)
                {
                    retorno = true;
                }
            }
            return retorno;
        }

        public static bool operator !=(Comercio a, Comercio b)
        {
            return !(a == b);
        }
    }
}
