﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Medina.Emiliano._2A
{
    public class Importador : Comercio
    {
        public EPaises paisOrigen;

        public Importador(string nombreComercio, float precioAlquiler, Comerciante comerciante, EPaises paisOrigen) : base(nombreComercio, comerciante, precioAlquiler)
        {
            this.paisOrigen = paisOrigen;
        }

        public string Mostrar()
        {
            return (string)((Comercio)this) + "\nTIPO: " + this.paisOrigen.ToString();
        }

        public static implicit operator double(Importador a)
        {
            return a._precioAlquiler;
        }

        public static bool operator ==(Importador a, Importador b)
        {
            bool retorno = false;
            if (Object.Equals(a, null) && Object.Equals(b, null))
            {
                retorno = true;
            }
            else if (!(Object.Equals(a, null) && Object.Equals(b, null)))
            {
                if ((Comercio)a == (Comercio)b && a.paisOrigen.Equals(b.paisOrigen))
                {
                    retorno = true;
                }
            }
            return retorno;
        }

        public static bool operator !=(Importador a, Importador b)
        {
            return !(a == b);
        }
    }
}
